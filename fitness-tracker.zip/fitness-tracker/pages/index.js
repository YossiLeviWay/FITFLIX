import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { PlusCircle, Trash2, Save, Calendar, BarChart2, Dumbbell, ChevronRight } from 'lucide-react';

export default function FitnessTracker() {
  // State for training programs, exercises, and workout logs
  const [programs, setPrograms] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedPrograms = localStorage.getItem('fitnessPrograms');
      return savedPrograms ? JSON.parse(savedPrograms) : [
        { id: 1, name: 'Upper Body', exercises: [1, 2] },
        { id: 2, name: 'Lower Body', exercises: [3, 4] }
      ];
    }
    return [
      { id: 1, name: 'Upper Body', exercises: [1, 2] },
      { id: 2, name: 'Lower Body', exercises: [3, 4] }
    ];
  });
  
  const [exercises, setExercises] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedExercises = localStorage.getItem('fitnessExercises');
      return savedExercises ? JSON.parse(savedExercises) : [
        { id: 1, name: 'Bench Press', category: 'Chest' },
        { id: 2, name: 'Pull Ups', category: 'Back' },
        { id: 3, name: 'Squats', category: 'Legs' },
        { id: 4, name: 'Deadlifts', category: 'Legs' }
      ];
    }
    return [
      { id: 1, name: 'Bench Press', category: 'Chest' },
      { id: 2, name: 'Pull Ups', category: 'Back' },
      { id: 3, name: 'Squats', category: 'Legs' },
      { id: 4, name: 'Deadlifts', category: 'Legs' }
    ];
  });
  
  const [workoutLogs, setWorkoutLogs] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedLogs = localStorage.getItem('fitnessLogs');
      return savedLogs ? JSON.parse(savedLogs) : [
        { id: 1, date: '2025-04-01', programId: 1, sets: [
          { exerciseId: 1, sets: [
            { weight: 135, reps: 10 },
            { weight: 155, reps: 8 },
            { weight: 175, reps: 6 }
          ]},
          { exerciseId: 2, sets: [
            { weight: 0, reps: 12 },
            { weight: 25, reps: 10 },
            { weight: 35, reps: 8 }
          ]}
        ]},
        { id: 2, date: '2025-04-03', programId: 2, sets: [
          { exerciseId: 3, sets: [
            { weight: 185, reps: 10 },
            { weight: 205, reps: 8 },
            { weight: 225, reps: 6 }
          ]},
          { exerciseId: 4, sets: [
            { weight: 225, reps: 8 },
            { weight: 275, reps: 6 },
            { weight: 315, reps: 4 }
          ]}
        ]},
        { id: 3, date: '2025-04-05', programId: 1, sets: [
          { exerciseId: 1, sets: [
            { weight: 135, reps: 12 },
            { weight: 155, reps: 10 },
            { weight: 175, reps: 8 }
          ]},
          { exerciseId: 2, sets: [
            { weight: 0, reps: 15 },
            { weight: 25, reps: 12 },
            { weight: 35, reps: 10 }
          ]}
        ]},
      ];
    }
    return [
      { id: 1, date: '2025-04-01', programId: 1, sets: [
        { exerciseId: 1, sets: [
          { weight: 135, reps: 10 },
          { weight: 155, reps: 8 },
          { weight: 175, reps: 6 }
        ]},
        { exerciseId: 2, sets: [
          { weight: 0, reps: 12 },
          { weight: 25, reps: 10 },
          { weight: 35, reps: 8 }
        ]}
      ]},
      { id: 2, date: '2025-04-03', programId: 2, sets: [
        { exerciseId: 3, sets: [
          { weight: 185, reps: 10 },
          { weight: 205, reps: 8 },
          { weight: 225, reps: 6 }
        ]},
        { exerciseId: 4, sets: [
          { weight: 225, reps: 8 },
          { weight: 275, reps: 6 },
          { weight: 315, reps: 4 }
        ]}
      ]},
      { id: 3, date: '2025-04-05', programId: 1, sets: [
        { exerciseId: 1, sets: [
          { weight: 135, reps: 12 },
          { weight: 155, reps: 10 },
          { weight: 175, reps: 8 }
        ]},
        { exerciseId: 2, sets: [
          { weight: 0, reps: 15 },
          { weight: 25, reps: 12 },
          { weight: 35, reps: 10 }
        ]}
      ]},
    ];
  });

  // UI states
  const [activeTab, setActiveTab] = useState('workout');
  const [selectedProgramId, setSelectedProgramId] = useState(1);
  const [selectedExerciseId, setSelectedExerciseId] = useState(null);
  const [currentWorkout, setCurrentWorkout] = useState({
    date: new Date().toISOString().split('T')[0],
    programId: 1,
    sets: []
  });
  
  // Form states
  const [newProgramName, setNewProgramName] = useState('');
  const [newExerciseName, setNewExerciseName] = useState('');
  const [newExerciseCategory, setNewExerciseCategory] = useState('');
  const [newSet, setNewSet] = useState({ weight: '', reps: '' });

  // Save to localStorage when state changes
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('fitnessPrograms', JSON.stringify(programs));
      localStorage.setItem('fitnessExercises', JSON.stringify(exercises));
      localStorage.setItem('fitnessLogs', JSON.stringify(workoutLogs));
    }
  }, [programs, exercises, workoutLogs]);

  // Add new program
  const addProgram = () => {
    if (!newProgramName.trim()) return;
    
    const newId = programs.length ? Math.max(...programs.map(p => p.id)) + 1 : 1;
    setPrograms([...programs, { id: newId, name: newProgramName, exercises: [] }]);
    setNewProgramName('');
  };

  // Add new exercise
  const addExercise = () => {
    if (!newExerciseName.trim() || !newExerciseCategory.trim()) return;
    
    const newId = exercises.length ? Math.max(...exercises.map(e => e.id)) + 1 : 1;
    setExercises([...exercises, { 
      id: newId, 
      name: newExerciseName, 
      category: newExerciseCategory 
    }]);
    
    setNewExerciseName('');
    setNewExerciseCategory('');
  };

  // Add exercise to program
  const addExerciseToProgram = (exerciseId) => {
    const program = programs.find(p => p.id === selectedProgramId);
    if (!program || program.exercises.includes(exerciseId)) return;
    
    setPrograms(programs.map(p => 
      p.id === selectedProgramId 
        ? { ...p, exercises: [...p.exercises, exerciseId] } 
        : p
    ));
  };

  // Remove exercise from program
  const removeExerciseFromProgram = (exerciseId) => {
    setPrograms(programs.map(p => 
      p.id === selectedProgramId 
        ? { ...p, exercises: p.exercises.filter(id => id !== exerciseId) } 
        : p
    ));
  };

  // Set up current workout
  const setupWorkout = () => {
    const program = programs.find(p => p.id === currentWorkout.programId);
    if (!program) return;
    
    const workoutSets = program.exercises.map(exerciseId => ({
      exerciseId,
      sets: []
    }));
    
    setCurrentWorkout({ ...currentWorkout, sets: workoutSets });
  };

  // Add set to current workout
  const addSetToWorkout = (exerciseId) => {
    if (!newSet.weight || !newSet.reps) return;
    
    const weight = parseFloat(newSet.weight);
    const reps = parseInt(newSet.reps, 10);
    
    setCurrentWorkout({
      ...currentWorkout,
      sets: currentWorkout.sets.map(item => 
        item.exerciseId === exerciseId
          ? { ...item, sets: [...item.sets, { weight, reps }] }
          : item
      )
    });
    
    setNewSet({ weight: '', reps: '' });
  };

  // Save current workout
  const saveWorkout = () => {
    // Validate workout data
    if (!currentWorkout.date || !currentWorkout.programId || 
        !currentWorkout.sets.length || 
        currentWorkout.sets.some(item => !item.sets.length)) {
      alert('Please complete your workout before saving');
      return;
    }
    
    const newId = workoutLogs.length ? Math.max(...workoutLogs.map(log => log.id)) + 1 : 1;
    
    setWorkoutLogs([...workoutLogs, { 
      id: newId,
      date: currentWorkout.date,
      programId: currentWorkout.programId,
      sets: currentWorkout.sets
    }]);
    
    // Reset current workout
    setCurrentWorkout({
      date: new Date().toISOString().split('T')[0],
      programId: currentWorkout.programId,
      sets: []
    });
  };

  // Get all logs for a specific exercise
  const getExerciseLogs = (exerciseId) => {
    const result = [];
    
    workoutLogs.forEach(log => {
      const exerciseLog = log.sets.find(item => item.exerciseId === exerciseId);
      if (exerciseLog && exerciseLog.sets.length) {
        // Calculate max weight and volume for each workout
        const maxWeight = Math.max(...exerciseLog.sets.map(set => set.weight));
        const totalVolume = exerciseLog.sets.reduce((sum, set) => sum + (set.weight * set.reps), 0);
        
        result.push({
          date: log.date,
          maxWeight,
          totalVolume,
          sets: exerciseLog.sets.length
        });
      }
    });
    
    return result.sort((a, b) => new Date(a.date) - new Date(b.date));
  };

  // Render specific sections based on the active tab
  const renderContent = () => {
    switch (activeTab) {
      case 'programs':
        return renderProgramsTab();
      case 'exercises':
        return renderExercisesTab();
      case 'workout':
        return renderWorkoutTab();
      case 'progress':
        return renderProgressTab();
      default:
        return renderWorkoutTab();
    }
  };

  // Render Programs Tab
  const renderProgramsTab = () => (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-6 text-red-600">Training Programs</h2>
      
      {/* Add New Program */}
      <div className="mb-8 p-4 bg-gray-900 rounded-md border border-gray-800">
        <h3 className="font-semibold mb-3 text-gray-300">Add New Program</h3>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Program Name"
            value={newProgramName}
            onChange={(e) => setNewProgramName(e.target.value)}
            className="flex-grow p-2 bg-gray-800 border border-gray-700 rounded text-white"
          />
          <button 
            onClick={addProgram}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded flex items-center gap-1 transition-colors"
          >
            <PlusCircle size={16} />
            Add
          </button>
        </div>
      </div>
      
      {/* Edit Program */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3 text-gray-300">Edit Program</h3>
        <select 
          value={selectedProgramId} 
          onChange={(e) => setSelectedProgramId(parseInt(e.target.value))}
          className="w-full p-3 bg-gray-800 border border-gray-700 rounded mb-4 text-white"
        >
          {programs.map(program => (
            <option key={program.id} value={program.id}>{program.name}</option>
          ))}
        </select>
        
        {selectedProgramId && (
          <>
            <h4 className="font-semibold mb-3 text-gray-300">Exercises in this program:</h4>
            <ul className="mb-6 bg-gray-900 rounded-md overflow-hidden">
              {programs
                .find(p => p.id === selectedProgramId)?.exercises
                .map(exerciseId => {
                  const exercise = exercises.find(e => e.id === exerciseId);
                  return exercise ? (
                    <li key={exercise.id} className="flex justify-between items-center p-3 border-b border-gray-800">
                      <span className="text-white">{exercise.name} <span className="text-gray-400">({exercise.category})</span></span>
                      <button 
                        onClick={() => removeExerciseFromProgram(exercise.id)}
                        className="text-red-500 hover:text-red-400 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </li>
                  ) : null;
                })
              }
            </ul>
            
            <h4 className="font-semibold mb-3 text-gray-300">Add exercises to program:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {exercises.filter(exercise => 
                !programs.find(p => p.id === selectedProgramId)?.exercises.includes(exercise.id)
              ).map(exercise => (
                <div key={exercise.id} className="flex justify-between items-center p-3 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors">
                  <span className="text-white">{exercise.name} <span className="text-gray-400">({exercise.category})</span></span>
                  <button 
                    onClick={() => addExerciseToProgram(exercise.id)}
                    className="text-red-500 hover:text-red-400 transition-colors"
                  >
                    <PlusCircle size={16} />
                  </button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );

  // Render Exercises Tab
  const renderExercisesTab = () => (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-6 text-red-600">Exercises Library</h2>
      
      {/* Add New Exercise */}
      <div className="mb-8 p-4 bg-gray-900 rounded-md border border-gray-800">
        <h3 className="font-semibold mb-3 text-gray-300">Add New Exercise</h3>
        <div className="flex flex-col gap-3">
          <input
            type="text"
            placeholder="Exercise Name"
            value={newExerciseName}
            onChange={(e) => setNewExerciseName(e.target.value)}
            className="p-3 bg-gray-800 border border-gray-700 rounded text-white"
          />
          <input
            type="text"
            placeholder="Category (e.g., Chest, Back, Legs)"
            value={newExerciseCategory}
            onChange={(e) => setNewExerciseCategory(e.target.value)}
            className="p-3 bg-gray-800 border border-gray-700 rounded text-white"
          />
          <button 
            onClick={addExercise}
            className="px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded flex items-center gap-2 transition-colors"
          >
            <PlusCircle size={16} />
            Add Exercise
          </button>
        </div>
      </div>
      
      {/* Exercise List */}
      <div>
        <h3 className="font-semibold mb-3 text-gray-300">Exercise Library</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {exercises.map(exercise => (
            <div key={exercise.id} className="p-4 bg-gray-800 rounded-md border border-gray-700 hover:border-gray-600 transition-colors">
              <div className="font-medium text-white">{exercise.name}</div>
              <div className="text-sm text-gray-400">{exercise.category}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Render Workout Tab
  const renderWorkoutTab = () => (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-6 text-red-600">Log Workout</h2>
      
      {/* Workout Setup */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row gap-3 mb-4">
          <div className="flex-grow">
            <label className="block text-sm font-medium mb-1 text-gray-300">Date</label>
            <input
              type="date"
              value={currentWorkout.date}
              onChange={(e) => setCurrentWorkout({ ...currentWorkout, date: e.target.value })}
              className="w-full p-3 bg-gray-800 border border-gray-700 rounded text-white"
            />
          </div>
          <div className="flex-grow">
            <label className="block text-sm font-medium mb-1 text-gray-300">Program</label>
            <select 
              value={currentWorkout.programId} 
              onChange={(e) => setCurrentWorkout({ ...currentWorkout, programId: parseInt(e.target.value) })}
              className="w-full p-3 bg-gray-800 border border-gray-700 rounded text-white"
            >
              {programs.map(program => (
                <option key={program.id} value={program.id}>{program.name}</option>
              ))}
            </select>
          </div>
          <div className="self-end">
            <button 
              onClick={setupWorkout}
              className="w-full px-6 py-3 bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
            >
              Start Workout
            </button>
          </div>
        </div>
      </div>
      
      {/* Current Workout */}
      {currentWorkout.sets.length > 0 && (
        <div className="mb-8">
          <h3 className="font-semibold mb-3 text-gray-300">
            {programs.find(p => p.id === currentWorkout.programId)?.name} - {currentWorkout.date}
          </h3>
          
          {currentWorkout.sets.map((item) => {
            const exercise = exercises.find(e => e.id === item.exerciseId);
            return exercise ? (
              <div key={exercise.id} className="mb-6 p-4 bg-gray-900 rounded-md border border-gray-800">
                <h4 className="font-medium mb-3 text-white">{exercise.name} <span className="text-gray-400">({exercise.category})</span></h4>
                
                {/* Existing Sets */}
                {item.sets.length > 0 && (
                  <table className="w-full mb-4 border-collapse">
                    <thead>
                      <tr className="text-left bg-gray-800">
                        <th className="p-2 text-gray-300 rounded-tl-md">Set</th>
                        <th className="p-2 text-gray-300">Weight</th>
                        <th className="p-2 text-gray-300 rounded-tr-md">Reps</th>
                      </tr>
                    </thead>
                    <tbody>
                      {item.sets.map((set, index) => (
                        <tr key={index} className="border-b border-gray-800 text-white">
                          <td className="p-2">{index + 1}</td>
                          <td className="p-2">{set.weight} lbs</td>
                          <td className="p-2">{set.reps}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
                
                {/* Add New Set */}
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Weight (lbs)"
                    value={newSet.weight}
                    onChange={(e) => setNewSet({ ...newSet, weight: e.target.value })}
                    className="flex-grow p-3 bg-gray-800 border border-gray-700 rounded text-white"
                    min="0"
                  />
                  <input
                    type="number"
                    placeholder="Reps"
                    value={newSet.reps}
                    onChange={(e) => setNewSet({ ...newSet, reps: e.target.value })}
                    className="flex-grow p-3 bg-gray-800 border border-gray-700 rounded text-white"
                    min="1"
                  />
                  <button 
                    onClick={() => addSetToWorkout(exercise.id)}
                    className="px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
                  >
                    Add Set
                  </button>
                </div>
              </div>
            ) : null;
          })}
          
          <button 
            onClick={saveWorkout}
            className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white rounded flex items-center gap-2 transition-colors"
          >
            <Save size={18} />
            Save Workout
          </button>
        </div>
      )}
      
      {/* Workout History */}
      <div>
        <h3 className="font-semibold mb-3 text-gray-300">Recent Workouts</h3>
        {workoutLogs.slice(-3).reverse().map(log => {
          const program = programs.find(p => p.id === log.programId);
          return (
            <div key={log.id} className="mb-3 p-4 bg-gray-900 rounded-md border border-gray-800 hover:border-gray-700 transition-colors">
              <div className="flex justify-between">
                <div className="font-medium text-white">{program?.name}</div>
                <div className="text-sm text-gray-400">{log.date}</div>
              </div>
              <div className="text-sm text-gray-400 mt-1">
                {log.sets.length} exercises, {log.sets.reduce((sum, ex) => sum + ex.sets.length, 0)} sets
              </div>
              <div className="mt-2 flex justify-end">
                <ChevronRight size={16} className="text-red-500" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  // Render Progress Tab
  const renderProgressTab = () => (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-6 text-red-600">Progress Charts</h2>
      
      {/* Exercise Selector */}
      <div className="mb-6">
        <label className="block text-sm font-medium mb-2 text-gray-300">Select Exercise</label>
        <select 
          value={selectedExerciseId || ''} 
          onChange={(e) => setSelectedExerciseId(parseInt(e.target.value))}
          className="w-full p-3 bg-gray-800 border border-gray-700 rounded text-white"
        >
          <option value="">Select an exercise</option>
          {exercises.map(exercise => (
            <option key={exercise.id} value={exercise.id}>{exercise.name}</option>
          ))}
        </select>
      </div>
      
      {/* Progress Charts */}
      {selectedExerciseId && (
        <div>
          <h3 className="font-semibold mb-3 text-gray-300">
            {exercises.find(e => e.id === selectedExerciseId)?.name} Progress
          </h3>
          
          {getExerciseLogs(selectedExerciseId).length > 0 ? (
            <div className="grid grid-cols-1 gap-6">
              {/* Max Weight Chart */}
              <div className="p-4 bg-gray-900 rounded-md border border-gray-800">
                <h4 className="font-medium mb-3 text-white">Max Weight Progression</h4>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={getExerciseLogs(selectedExerciseId)}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                      <XAxis dataKey="date" stroke="#999" />
                      <YAxis stroke="#999" />
                      <Tooltip contentStyle={{ backgroundColor: '#222', borderColor: '#444', color: '#fff' }} />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="maxWeight" 
                        name="Max Weight (lbs)" 
                        stroke="#E50914" 
                        strokeWidth={3} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              {/* Volume Chart */}
              <div className="p-4 bg-gray-900 rounded-md border border-gray-800">
                <h4 className="font-medium mb-3 text-white">Total Volume Progression</h4>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={getExerciseLogs(selectedExerciseId)}