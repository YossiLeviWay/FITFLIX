# FITFLIX - Netflix-Style Fitness Tracker

A modern fitness tracking web application with Netflix-inspired UI. Track your workouts, manage training programs, and visualize your progress over time.

## Features

- **Training Program Management:** Create and customize workout programs
- **Exercise Library:** Build your personal exercise database
- **Workout Logging:** Record sets, reps, and weights for each exercise
- **Progress Visualization:** Track your improvements with interactive charts
- **Netflix-Inspired UI:** Dark theme with red accents and card-based layout

## Technologies Used

- Next.js
- React
- Tailwind CSS
- Recharts (for data visualization)
- Lucide Icons

## Getting Started

### Prerequisites

- Node.js 14.6.0 or newer

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/fitness-tracker.git
cd fitness-tracker
```

2. Install dependencies
```bash
npm install
```

3. Run the development server
```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Deployment on Vercel

The easiest way to deploy this app is using Vercel:

1. Push your code to a GitHub repository
2. Import the project into Vercel
3. Vercel will detect it's a Next.js app and set up the build configuration automatically

## Data Storage

All user data is stored in the browser's localStorage. No data is sent to any server.

## License

MIT
